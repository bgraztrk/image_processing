const myImage = document.getElementById("photo");
const localHost = "http://127.0.0.1:5500";

Promise.all([
  faceapi.nets.faceRecognitionNet.loadFromUri(`${localHost}/models-recognition`),
  faceapi.nets.faceLandmark68Net.loadFromUri(`${localHost}/models-recognition`),
  faceapi.nets.ssdMobilenetv1.loadFromUri(`${localHost}/models-recognition`)
]).then(open);


async function open(){
    document.body.append("All Model Done..");

    //resim değiştiğinde
    myPhoto.addEventListener("change", async () => {
      
      const selectPhoto = await faceapi.bufferToImage(myPhoto.files[0]);
      document.body.append(selectPhoto);
    
      //yüzlerin tespit edilmesi
      const panel = await faceapi
      .detectAllFaces(selectPhoto)
      .withFaceLandmarks()
      .withFaceDescriptors();

      const panelSize = {
        width : selectPhoto.width,
        height : selectPhoto.height      
      }

      const resizedDetections = faceapi.resizeResults(panel, panelSize);
      console.log(resizedDetections);
    
      const frame = faceapi.createCanvasFromMedia(selectPhoto);
      document.body.append(frame);
      faceapi.matchDimensions(frame, panelSize);

      /*resizedDetections.forEach(d => {
      const box = d.detection.box;
      const drawBox = new faceapi.draw.DrawBox(box, { label: "Kimdir Bu?" });
      drawBox.draw(canvas);
      });*/

      const sonuclar = resizedDetections.map(d =>
        faceMatcher.findBestMatch(d.descriptor)
      );

      sonuclar.forEach((sonuclar, x) => {
        const kutu = resizedDetections[x].detection.kutu;
        const cizimKutu = new faceapi.draw.DrawBox(kutu, {
          label: result.toString()
        });
        cizimKutu.draw(frame);
      });

    });

    const etiketAlanları = await loadImages();
    const yüzEsleme = new faceapi.FaceMatcher(labelDescriptions, 0.6);
}

async function loadImages() {
  const labels = [
    "abdurrahman",
    "bugra",
    "eda",
    "melih"
  ];

  return Promise.all(
    etiketler.map(async etiket => {
      const alanlar = [];

      for (let i = 1; i <= 3; i++) {
        const photo = await faceapi.fetchImage(
          `${localHost}/library/${etiket}/${i}.jpeg`
        );

        const alanlar = await faceapi
          .detectSingleFace(photo)
          .withFaceLandmarks()
          .withFaceDescriptor();
        etiketler.push(alanlar.etiketler);
      }
      return new faceapi.LabeledFaceDescriptors(etiket, sonuçlar);
    })
  );
}