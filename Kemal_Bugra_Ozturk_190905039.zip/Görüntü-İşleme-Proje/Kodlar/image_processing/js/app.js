const record = document.getElementById('record');

//birden fazla veriyi aktarıcağım için all dedim ve birden fazla veri olduğu için de array kullandım.
Promise.all([
    faceapi.nets.tinyFaceDetector.loadFromUri("/models-emotion"),
    faceapi.nets.faceLandmark68Net.loadFromUri("/models-emotion"),
    faceapi.nets.faceRecognitionNet.loadFromUri("/models-emotion"),
    faceapi.nets.faceExpressionNet.loadFromUri("/models-emotion")
  ]).then(openRecord());

//kamerayı açma bloğu 
function openRecord() {
    
    //return false; 
    
    navigator.getUserMedia(
        {
            record : {}
        },
        stream => (video.srcObject = stream), //kameradan gelen veriyi stream içine aktar
        err => console.log(err) //hata varsa ekrana log bastır
    );
}

video.addEventListener("play", () => {

    const square = faceapi.createCanvasFromMedia(record);
    document.body.append(square);

    const boxSize = {
        width : record.width,
        height : record.height
    }

    faceapi.matchDimensions(square, squareSize);

    //setInterval yapmamın sebebi her 100ms bir api ye istekte bulun
    //burdaki yapacağım işlemler async olacağı için yani kütüphanenin bana ne kadar sürede geri dönüş yapacağını bilmediğim için beklemem gerekir
    //bunun içinde kullanıcağım kelime await olması gerekir bu kelimeyi kullanabilmem için de fonksiyonun async olması gerekir o yüzden setInterval'ın da başına async demem gerekir
    setInterval( async () => {

        const panel = await faceapi.detectAllFaces(record, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceExpressions();

        square.getContext("2d").clearRect(0,0, square.width, square.height);
        const resizedDetections = faceapi.resizeResults(panel, squareSize);
        
        faceapi.draw.drawDetections(square, resizedDetections);

        faceapi.draw.drawFaceLandmarks(square, resizedDetections);

        faceapi.draw.drawFaceExpressions(square, resizedDetections);


        //console.log(detections)
    }, 100)
})
